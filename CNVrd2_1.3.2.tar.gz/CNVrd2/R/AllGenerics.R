setGeneric("countReadInWindow",
           function(Object, ...){standardGeneric("countReadInWindow")})
setGeneric("segmentSamples",
           function(Object, ...){standardGeneric("segmentSamples")})
setGeneric("segmentSamplesUsingPopInformation",
           function(Object, ...){standardGeneric("segmentSamplesUsingPopInformation")})
setGeneric("plotCNVrd2",
           function(Object, ...){standardGeneric("plotCNVrd2")})
setGeneric("emnormalCNV",
           function(Object, ...){standardGeneric("emnormalCNV")})
setGeneric("searchGroupCNVs",
           function(Object, ...){standardGeneric("searchGroupCNVs")})
setGeneric("groupCNVs",
           function(Object, ...){standardGeneric("groupCNVs")})
setGeneric("plotPolymorphicRegion",
           function(Object, ...){standardGeneric("plotPolymorphicRegion")})
setGeneric("identifyPolymorphicRegion",
           function(Object, ...){standardGeneric("identifyPolymorphicRegion")})

